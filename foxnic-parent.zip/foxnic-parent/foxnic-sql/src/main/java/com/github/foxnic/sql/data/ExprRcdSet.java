package com.github.foxnic.sql.data;

public interface ExprRcdSet {

}
