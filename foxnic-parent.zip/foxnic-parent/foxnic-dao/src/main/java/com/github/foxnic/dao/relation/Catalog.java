package com.github.foxnic.dao.relation;

import java.util.LinkedHashMap;

/**
 * 用于分组汇总
 * */
public class Catalog extends LinkedHashMap<String, Double> {}
