package com.github.foxnic.dao;

public class Meta {

	public static final String BASE_PACKAGE="com.github.foxnic.dao";
 
	
	 
	
}
