package com.github.foxnic.dao.excel;

public  enum Version
{
	V2003,V2007 ;
}
