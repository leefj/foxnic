package com.github.foxnic.dao.data;

public enum SaveAction {
	INSERT,UPDATE,NONE; 
}
