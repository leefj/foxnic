package com.github.foxnic.commons.lang.function;

public interface SetterFunction<T,R> {
	void apply(T e,R value);
}
