package com.demo.framework;

public class SuperController {
	
}
