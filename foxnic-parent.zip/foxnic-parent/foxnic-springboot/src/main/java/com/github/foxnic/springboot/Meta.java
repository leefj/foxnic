package com.github.foxnic.springboot;

public class Meta {


	public static final String BASE_PACKAGE="com.github.foxnic.springboot";


}
