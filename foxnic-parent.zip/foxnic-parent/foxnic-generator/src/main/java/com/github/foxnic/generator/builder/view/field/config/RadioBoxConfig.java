package com.github.foxnic.generator.builder.view.field.config;

import com.github.foxnic.sql.meta.DBField;

public class RadioBoxConfig extends OptionFieldConfig<RadioBoxConfig> {

    public RadioBoxConfig(DBField field) {
        super(field);
    }
}
