package com.github.foxnic.generator.builder.view.config;

public class FormWindowConfig {




    private String width = "500px" ;
    private Integer bottomSpace = null ;

    public Integer getBottomSpace() {
        return bottomSpace;
    }

    public void setBottomSpace(Integer bottomSpace) {
        this.bottomSpace = bottomSpace;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }

}
