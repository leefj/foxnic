package com.github.foxnic.generator.builder.view.field.config;

public class TextInputConfig {


    public String getDefaultText() {
        return defaultText;
    }

    private String defaultText;

    public void setDefaultText(String text) {
        this.defaultText=text;
    }
}
