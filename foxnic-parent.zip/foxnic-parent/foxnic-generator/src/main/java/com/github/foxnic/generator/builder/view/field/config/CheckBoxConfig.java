package com.github.foxnic.generator.builder.view.field.config;

import com.github.foxnic.sql.meta.DBField;

public class CheckBoxConfig extends OptionFieldConfig<CheckBoxConfig> {

    public CheckBoxConfig(DBField field) {
        super(field);
    }
}
